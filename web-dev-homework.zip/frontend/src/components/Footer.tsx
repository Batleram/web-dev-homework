import React from 'react'
import "../styles/Footer.component.css"

export const Footer = () => {
    return (
        <footer id="footer">Copyright Batleram 2022&trade;</footer>
    )
}
