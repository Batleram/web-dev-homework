import React from "react"
import "../styles/Landing.page.css"

export const Landing = () => {
    return (
        <>
            <section className="home-section">
                <h2>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur cumque voluptatum aliquid totam fugiat nulla rem quam, quo, mollitia earum eius iusto fuga. Quo cupiditate odio at quam, beatae fugiat.</h2>
            </section>
            <section className="home-section">
                <h2>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur cumque voluptatum aliquid totam fugiat nulla rem quam, quo, mollitia earum eius iusto fuga. Quo cupiditate odio at quam, beatae fugiat.</h2>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Libero reiciendis alias commodi neque sint ratione atque, voluptatum maxime unde! Ipsa minus veritatis magni perferendis cupiditate dolor culpa exercitationem deserunt qui.</p>
            </section>
            <section className="home-section">
                <h2>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur cumque voluptatum aliquid totam fugiat nulla rem quam, quo, mollitia earum eius iusto fuga. Quo cupiditate odio at quam, beatae fugiat.</h2>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Libero reiciendis alias commodi neque sint ratione atque, voluptatum maxime unde! Ipsa minus veritatis magni perferendis cupiditate dolor culpa exercitationem deserunt qui.</p>
            </section>
            <section className="home-section">
                <h2>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur cumque voluptatum aliquid totam fugiat nulla rem quam, quo, mollitia earum eius iusto fuga. Quo cupiditate odio at quam, beatae fugiat.</h2>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Libero reiciendis alias commodi neque sint ratione atque, voluptatum maxime unde! Ipsa minus veritatis magni perferendis cupiditate dolor culpa exercitationem deserunt qui.</p>
            </section>
        </>
    )
}
