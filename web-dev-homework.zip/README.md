# Setup
Creer un ficher .env dans la racine du projet
```
ROOTPASS=<mot de passe root pour db>
DBUSER=<utilisateur pour la db>
DBPASS=<mot de passe pour la db>
```

# Start
Pour lancer le projet, exécuter la commande suivante:
`docker-compose up -d --build`

# Site Demo
Accedez a une démo sur le site:
https://amogousse.com:5000
