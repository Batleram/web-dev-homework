<?php
define("DEFAULT_ERROR_LANG", "FRENCH");
