<?php
define("ROOT", __DIR__);
