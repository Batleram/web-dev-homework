<?php

echo "text";
