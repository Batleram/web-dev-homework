<!DOCTYPE html>
<html>

<head>
    <title>Web Development Homework</title>
    <link rel="stylesheet" href="./index.css" />
</head>

<body>
    <?php include "navbar.php"; ?>
    <section class="home-section">
        <h2>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur cumque voluptatum aliquid totam fugiat nulla rem quam, quo, mollitia earum eius iusto fuga. Quo cupiditate odio at quam, beatae fugiat.</h2>
    </section>
    <section class="home-section">
        <h2>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur cumque voluptatum aliquid totam fugiat nulla rem quam, quo, mollitia earum eius iusto fuga. Quo cupiditate odio at quam, beatae fugiat.</h2>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Libero reiciendis alias commodi neque sint ratione atque, voluptatum maxime unde! Ipsa minus veritatis magni perferendis cupiditate dolor culpa exercitationem deserunt qui.</p>
    </section>
    <section class="home-section">
        <h2>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur cumque voluptatum aliquid totam fugiat nulla rem quam, quo, mollitia earum eius iusto fuga. Quo cupiditate odio at quam, beatae fugiat.</h2>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Libero reiciendis alias commodi neque sint ratione atque, voluptatum maxime unde! Ipsa minus veritatis magni perferendis cupiditate dolor culpa exercitationem deserunt qui.</p>
    </section>
    <section class="home-section">
        <h2>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur cumque voluptatum aliquid totam fugiat nulla rem quam, quo, mollitia earum eius iusto fuga. Quo cupiditate odio at quam, beatae fugiat.</h2>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Libero reiciendis alias commodi neque sint ratione atque, voluptatum maxime unde! Ipsa minus veritatis magni perferendis cupiditate dolor culpa exercitationem deserunt qui.</p>
    </section>
    <?php include "footer.php"; ?>
</body>

</html>
