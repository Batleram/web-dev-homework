<html>
<footer id="footer">Copyright Batleram 2069&trade;</footer>
<style>
    #footer {
        text-align: center;
        font-size: 0.8rem;
    }
</style>

</html>
